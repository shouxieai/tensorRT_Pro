# ONNX Parser
- 这几个文件提取自官方的onnx-tensorrt，去掉python方面，其他都在
- 另外增加了Plugin节点的支持
- https://github.com/onnx/onnx-tensorrt