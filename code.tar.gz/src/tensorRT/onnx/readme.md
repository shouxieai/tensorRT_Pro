# ONNX
- 这几个文件来自于对ONNX的编译后提取的结果，由protoc生成的cpp
- https://github.com/onnx/onnx